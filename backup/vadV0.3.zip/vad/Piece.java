package vad;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Piece
{
	private JButton		pieceSquareButton;
	private int			row				= -1;
	private int			column			= -1;
	private int			type			= -1;
	private int			teamColor		= -1;
	private final int	BLACK_PAWN_ROW	= 1;
	private final int	WHITE_PAWN_ROW	= 6;
	private boolean		kingHasMoved	= false;
	private Color		blankSquareColor;

	public Piece(JButton b, Color blankSquareColor)
	{
		setPieceSquareButton(b);
		this.blankSquareColor = blankSquareColor;
	}

	public boolean checkMate(Piece[][] bg, int kingOfInterestColor, boolean checkBlockValidation)
	{
		if (!underCheck(bg, kingOfInterestColor, checkBlockValidation))
		{
			return false;
		}

		boolean kingCanMove = false;
		boolean anyPieceHasCheckStoppingMove = false;
		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++)
			{
				if (bg[ii][jj].getColor() != kingOfInterestColor)
				{
					continue;
				}

				boolean[][] moveLocs = bg[ii][jj].getPossibleMoves(bg);

				if (bg[ii][jj].getType() != ChessGUI.KING)
				{
					for (int i = 0; i < 8; i++)
					{
						for (int j = 0; j < 8; j++)
						{
							if (moveLocs[i][j])
							{
								anyPieceHasCheckStoppingMove = true;
							}
						}
					}

				}
				else
				{
					for (int i = 0; i < 8; i++)
					{
						for (int j = 0; j < 8; j++)
						{
							if (moveLocs[i][j])
							{
								kingCanMove = true;
							}
						}
					}
				}
			}
		}

		if (!kingCanMove)
		{
			if (!anyPieceHasCheckStoppingMove)
			{
				return true;
			}
		}
		return false;
	}

	public void destroyPiece()
	{
		pieceSquareButton.setBackground(blankSquareColor);
		type = -1;
		teamColor = -1;
		setPieceIcon(new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB)));
	}

	public boolean[][] getAllSquaresUnderEnemyAttack(Piece[][] bg, boolean protectionCheck)
	{
		boolean[][] grid = new boolean[8][8];

		Piece[][] enemyPieces = new Piece[8][8];

		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				Piece p = new Piece(new JButton(), Color.white);
				p.setType(bg[i][j].getType());
				p.setColor(bg[i][j].getColor());
				p.setPos(bg[i][j].getColumn(), bg[i][j].getRow());
				enemyPieces[i][j] = p;// bg[i][j];
			}
		}

		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (enemyPieces[i][j].getColor() == getColor())
				{
					enemyPieces[i][j].destroyPiece();
				}

				if (enemyPieces[i][j].getType() != -1)
				{
					boolean[][] result = enemyPieces[i][j].getAttackLocations(bg, protectionCheck);
					for (int ii = 0; ii < 8; ii++)
					{
						for (int jj = 0; jj < 8; jj++)
						{
							if (result[ii][jj])
							{
								grid[ii][jj] = true;
							}
						}
					}
				}
			}
		}
		return grid;
	}

	public boolean[][] getAttackLocations(Piece[][] bg, boolean protectionCheck)
	{
		boolean[][] grid = new boolean[8][8];

		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++)
			{
				grid[ii][jj] = false;
			}
		}

		switch (type)
		{
			case ChessGUI.BISHOP:
				//System.out.println("---------------------- CASE: ATTACK FOR BISHOP ----------");
				grid = runDiagonalCheck(bg, grid, protectionCheck);
				break;
			case ChessGUI.KING:
				//System.out.println("---------------------- CASE: ATTACK FOR KING ----------");
				grid = runKingCheck(bg, grid, true, protectionCheck); // the boolean in this
				// is RECURSION
				// AVOID
				break;
			case ChessGUI.KNIGHT:
				//System.out.println("---------------------- CASE: ATTACK FOR KNIGHT ----------");
				grid = runKnightCheck(bg, grid, protectionCheck);
				break;
			case ChessGUI.PAWN:
				//System.out.println("---------------------- CASE: ATTACK FOR PAWN ----------");
				grid = runPawnCheck(bg, grid, true, protectionCheck); // attack or move
				break;
			case ChessGUI.QUEEN:
				//System.out.println("---------------------- CASE: ATTACK FOR QUEEN ----------");
				grid = runStraightCheck(bg, grid, protectionCheck);
				grid = runDiagonalCheck(bg, grid, protectionCheck);
				break;
			case ChessGUI.ROOK:
				//System.out.println("---------------------- CASE: ATTACK FOR ROOK ----------");
				grid = runStraightCheck(bg, grid, protectionCheck);
				break;
		}

		return grid;
	}

	public Color getBlankSquareColor()
	{
		return blankSquareColor;
	}

	public int getColor()
	{
		return teamColor;
	}

	public int getColumn()
	{
		return column;
	}

	public Icon getPieceIcon()
	{
		return pieceSquareButton.getIcon();
	}

	public JButton getPieceSquareButton()
	{
		return pieceSquareButton;
	}

	public boolean[][] getPossibleMoves(Piece[][] bg)
	{
		boolean[][] grid = new boolean[8][8];

		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++)
			{
				grid[ii][jj] = false;
			}
		}

		switch (type)
		{
			case ChessGUI.BISHOP:
				//System.out.println("---------------------- CASE: BISHOP ----------");
				// if (!currentPlayerUnderCheck) grid = this.runDiagonalCheck(bg, grid, false);
				grid = runDiagonalCheck(bg, grid, false);
				break;
			case ChessGUI.KING:
				//System.out.println("---------------------- CASE: KING ----------");
				grid = runKingCheck(bg, grid, false, false);
				break;
			case ChessGUI.KNIGHT:
				//System.out.println("---------------------- CASE: KNIGHT ----------");
				// if (!currentPlayerUnderCheck) grid = this.runKnightCheck(bg, grid);
				grid = runKnightCheck(bg, grid, false);
				break;
			case ChessGUI.PAWN:
				//System.out.println("---------------------- CASE: PAWN ----------");
				// if (!currentPlayerUnderCheck) grid = this.runPawnCheck(bg, grid, false);
				grid = runPawnCheck(bg, grid, false, false); // attack or move
				break;
			case ChessGUI.QUEEN:
				//System.out.println("---------------------- CASE: QUEEN ----------");
				/*
				 * if (!currentPlayerUnderCheck) { grid = this.runStraightCheck(bg, grid, false); grid = this.runDiagonalCheck(bg, grid, false); }
				 */
				grid = runStraightCheck(bg, grid, false);
				grid = runDiagonalCheck(bg, grid, false);
				break;
			case ChessGUI.ROOK:
				//System.out.println("---------------------- CASE: ROOK ----------");
				// if (!currentPlayerUnderCheck) grid = this.runStraightCheck(bg, grid, false);
				grid = runStraightCheck(bg, grid, false);
				break;
		}

		if (getType() != ChessGUI.KING) // 'this' is the selected piece
		{
			//System.out.println("Running block and blocked piece check");
			MoveManager.printPossibleMoves(grid);
			//System.out.println("Get ready!");
			Piece[][] tempBoard = new Piece[8][8];

			for (int ii = 0; ii < 8; ii++)
			{
				for (int jj = 0; jj < 8; jj++)
				{
					Piece p = new Piece(new JButton(), Color.white);
					p.setType(bg[ii][jj].getType());
					p.setColor(bg[ii][jj].getColor());
					p.setPos(bg[ii][jj].getColumn(), bg[ii][jj].getRow());
					tempBoard[ii][jj] = p;
				}
			}

			for (int ii = 0; ii < 8; ii++)
			{
				for (int jj = 0; jj < 8; jj++)
				{
					if (grid[ii][jj])
					{
						//System.out.println("Potentially valid move, need to check: " + ii + " " + jj);
						Piece original = new Piece(new JButton(), Color.white);
						original.setType(bg[ii][jj].getType());
						original.setColor(bg[ii][jj].getColor());
						original.setPos(bg[ii][jj].getColumn(), bg[ii][jj].getRow());

						Piece temp = new Piece(new JButton(), Color.white);

						Piece toBeRemovedForCheck = new Piece(new JButton(), Color.white);
						toBeRemovedForCheck.setType(getType());
						toBeRemovedForCheck.setColor(getColor());
						toBeRemovedForCheck.setPos(getColumn(), getRow());
						tempBoard[toBeRemovedForCheck.getColumn()][toBeRemovedForCheck.getRow()].destroyPiece();

						temp.setType(ChessGUI.PAWN);
						temp.setColor(getColor());
						temp.setPos(ii, jj);
						tempBoard[ii][jj] = temp;

						//System.out.println("Added temp piece: " + tempBoard[ii][jj].getColumn() + " " + tempBoard[ii][jj].getRow());
						//System.out.println("Destroyed piece: " + tempBoard[toBeRemovedForCheck.getColumn()][toBeRemovedForCheck.getRow()]);

						MoveManager.printPossibleMoves(grid);

						if (underCheck(tempBoard, getColor(), false))
						{
							grid[ii][jj] = false;
						}

						tempBoard[ii][jj].destroyPiece();
						tempBoard[ii][jj] = original;
						tempBoard[toBeRemovedForCheck.getColumn()][toBeRemovedForCheck.getRow()] = toBeRemovedForCheck;
					}
				}
			}
		}
		return grid;
	}

	public int getRow()
	{
		return row;
	}

	public int getType()
	{
		return type;
	}

	public boolean isKingHasMoved()
	{
		return kingHasMoved;
	}

	public boolean isValidPiece()
	{
		if ((getType() == -1) || (getRow() == -1) || (getColumn() == -1) || (getColor() == -1))
		{
			return false;
		}
		return true;
	}

	public boolean[][] runDiagonalCheck(Piece[][] bg, boolean[][] grid, boolean protectionCheck)
	{
		boolean ran = false;
		boolean ran2 = false;
		boolean ran3 = false;

		while (true)
		{
			int col = getColumn();
			int row = getRow();
			//System.out.println("StartDiagonalCheck: " + col + " " + row);
			while (((col < 8) && (row >= 0)) && (col >= 0) && (row < 8))
			{
				//System.out.println("DEBUG_DiagonalCheck: " + col + " " + row);

				if (bg[col][row].getType() == -1)
				{
					grid[col][row] = true;
				}
				else if (bg[col][row].getColor() != getColor())
				{
					grid[col][row] = true;
					if (bg[col][row].getType() != ChessGUI.KING)
						break;
				}
				else if ((bg[col][row].getColor() == getColor()) && protectionCheck && ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))) // if peice is not an enemy and protection check
				{
					grid[col][row] = true;
					break;
				}
				else if ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))
				{
					if (bg[col][row].getColor() == getColor())
					{
						break;
					}
				}

				if (ran2)
				{
					if (ran)
					{
						col--;
					}
					else
					{
						col++;
					}
					row--;
				}
				else
				{
					if (ran)
					{
						col--;
					}
					else
					{
						col++;
					}
					row++;
				}
			}
			if (ran3)
			{
				break;
			}

			if (ran && ran2)
			{
				ran3 = true;
				ran2 = true;
				ran = false;
				continue;
			}

			if (ran)
			{
				ran2 = true;
				ran = false;
			}

			ran = true;
		}
		return grid;
	}

	public boolean[][] runKingCheck(Piece[][] bg, boolean[][] grid, boolean recursiveAvoid, boolean protectionCheck) // TODO Fix this
	{
		int col = getColumn();
		int row = getRow();
		//System.out.println("StartKingCheck: " + col + " " + row + " " + recursiveAvoid);
		for (int i = -1; i < 2; i++)
		{
			row = getRow();
			row += i;
			for (int j = -1; j < 2; j++)
			{
				col = getColumn();
				col += j;

				if (((col >= 8) || (row < 0)) || (col < 0) || (row >= 8))
				{
					continue;
				}

				if (!recursiveAvoid && getAllSquaresUnderEnemyAttack(bg, false)[col][row])
				{
					continue;
				}

				if (bg[col][row].getType() == -1)
				{
					grid[col][row] = true;
				}
				else if ((bg[col][row].getColor() == getColor()) && protectionCheck && ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))) // if peice is not an enemy and protection check
				{
					grid[col][row] = true;
					break;
				}
				else if (bg[col][row].getColor() != getColor() && !recursiveAvoid) // if the piece is an enemy
				{   					
					// check that the enemy is not protected
					boolean[][] tempGrid = getAllSquaresUnderEnemyAttack(bg, true);// bg[col][row].getAttackLocations(bg, true);
					if (!tempGrid[col][row])
					{
						grid[col][row] = true;
					}
				}
			}
		}

		return grid;
	}

	public boolean[][] runKnightCheck(Piece[][] bg, boolean[][] grid, boolean protectionCheck)
	{
		for (int i = 0; i < 4; i++)
		{
			int col = getColumn();
			int row = getRow();
			//System.out.println("StartKnightCheck: " + col + " " + row);

			if (i == 0)
			{
				row -= 2;
			}
			else if (i == 1)
			{
				col += 2;
			}
			else if (i == 2)
			{
				row += 2;
			}
			else if (i == 3)
			{
				col -= 2;
			}

			for (int j = 0; j < 2; j++)
			{
				if ((i % 2) == 0)
				{
					col = getColumn();
				}
				else
				{
					row = getRow();
				}

				//System.out.println("DEBUG_KnightCheck: " + col + " " + row);

				if ((i % 2) == 0)
				{
					if (j == 0)
					{
						col--;
					}
					else
					{
						col++;
					}
				}
				else if (j == 0)
				{
					row--;
				}
				else
				{
					row++;
				}

				if (((col >= 8) || (row < 0)) || (col < 0) || (row >= 8))
				{
					continue;
				}

				if (bg[col][row].getType() == -1)
				{
					grid[col][row] = true;
				}
				else if ((bg[col][row].getColor() == getColor()) && protectionCheck && ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))) // if peice is not an enemy and protection check
				{
					grid[col][row] = true;
					break;
				}
				else if (bg[col][row].getColor() != getColor())
				{
					grid[col][row] = true;
				}
			}
		}
		return grid;
	}

	public boolean[][] runPawnCheck(Piece[][] bg, boolean[][] grid, boolean attack, boolean protectionCheck)
	{
		if (protectionCheck)
		{
			attack = true;
		}
		if (teamColor == ChessGUI.WHITE)
		{
			// check for edge of board
			if ((getRow() - 1) < 0)
			{
				return grid; // safety out of bounds check
			}
			// check if space straight ahead is blank
			if ((bg[getColumn()][getRow() - 1].getType() == -1) && !attack)
			{
				grid[getColumn()][getRow() - 1] = true;
			}
			// check if on starting row, can jump 2 spaces
			if ((getRow() == WHITE_PAWN_ROW) && !attack)
			{
				if (bg[getColumn()][getRow() - 1].getType() == -1)
				{
					if (bg[getColumn()][getRow() - 2].getType() == -1)
					{
						grid[getColumn()][getRow() - 2] = true;
					}
				}
			}

			// check for edge of board, then see if can attack right
			// ahead
			if (!((getColumn() + 1) > 7))
			{
				if ((bg[getColumn() + 1][getRow() - 1].getColor() != getColor()) || attack)
				{
					if ((bg[getColumn() + 1][getRow() - 1].getType() != -1) || attack)
					{
						grid[getColumn() + 1][getRow() - 1] = true;
					}
				}
			}
			// check for edge of board, then see if can attack left
			// ahead
			if (!((getColumn() - 1) < 0))
			{
				if ((bg[getColumn() - 1][getRow() - 1].getColor() != getColor()) || attack)
				{
					if ((bg[getColumn() - 1][getRow() - 1].getType() != -1) || attack)
					{
						grid[getColumn() - 1][getRow() - 1] = true;
					}
				}
			}

		}
		else
		{
			// check for edge of board
			if ((getRow() + 1) > 7)
			{
				return grid; // safety out of bounds check
			}
			// check if space straight ahead is blank
			if ((bg[getColumn()][getRow() + 1].getType() == -1) && !attack)
			{
				grid[getColumn()][getRow() + 1] = true;
			}
			// check if on starting row, can jump 2 spaces
			if ((getRow() == BLACK_PAWN_ROW) && !attack)
			{
				if (bg[getColumn()][getRow() + 1].getType() == -1)
				{
					if (bg[getColumn()][getRow() + 2].getType() == -1)
					{
						grid[getColumn()][getRow() + 2] = true;
					}
				}
			}

			// check for edge of board, then see if can attack right
			// ahead
			if (!((getColumn() - 1) < 0))
			{
				if ((bg[getColumn() - 1][getRow() + 1].getColor() != getColor()) || attack)
				{
					if ((bg[getColumn() - 1][getRow() + 1].getType() != -1) || attack)
					{
						grid[getColumn() - 1][getRow() + 1] = true;
					}
				}
			}
			// check for edge of board, then see if can attack left
			// ahead
			if (!((getColumn() + 1) > 7))
			{
				if ((bg[getColumn() + 1][getRow() + 1].getColor() != getColor()) || attack)
				{
					if ((bg[getColumn() + 1][getRow() + 1].getType() != -1) || attack)
					{
						grid[getColumn() + 1][getRow() + 1] = true;
					}
				}
			}
		}
		return grid;
	}

	public boolean[][] runStraightCheck(Piece[][] bg, boolean[][] grid, boolean protectionCheck)
	{
		for (int i = 0; i < 4; i++)
		{
			int col = getColumn();
			int row = getRow();
			//System.out.println("StartStraightCheck: " + col + " " + row);
			while (((col < 8) & (row >= 0)) && (col >= 0) && (row < 8))
			{
				//System.out.println("DEBUG_StraightCheck: " + col + " " + row);

				if (bg[col][row].getType() == -1)
				{
					grid[col][row] = true;
				}
				else if (bg[col][row].getColor() != getColor())
				{
					grid[col][row] = true;
					if (bg[col][row].getType() != ChessGUI.KING)
						break;
				}
				else if ((bg[col][row].getColor() == getColor()) && protectionCheck && ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))) // if peice is not an enemy and protection check
				{
					grid[col][row] = true;
					break;
				}
				else if ((getColumn() != bg[col][row].getColumn()) || (getRow() != bg[col][row].getRow()))
				{
					if (bg[col][row].getColor() == getColor())
					{
						break;
					}
				}

				if (i == 0)
				{
					col++;
				}
				else if (i == 1)
				{
					row++;
				}
				else if (i == 2)
				{
					col--;
				}
				else if (i == 3)
				{
					row--;
				}
			}
		}
		return grid;
	}

	public void setActionListener(ActionListener al)
	{
		pieceSquareButton.addActionListener(al);
	}

	public void setColor(int color)
	{
		teamColor = color;
	}

	public void setKingHasMoved(boolean kingHasMoved)
	{
		this.kingHasMoved = kingHasMoved;
	}

	public void setPieceIcon(Icon imageIcon)
	{
		pieceSquareButton.setIcon(imageIcon);
	}

	public void setPieceSquareButton(JButton pieceSquareButton)
	{
		this.pieceSquareButton = pieceSquareButton;
	}

	public void setPos(int col, int row)
	{
		this.row = row;
		column = col;
	}

	public void setType(int type)
	{
		this.type = type;
	}

	public boolean underCheck(Piece[][] bg, int kingOfInterestColor, boolean checkBlockValidation)
	{
		boolean[][] enemyAttack = getAllSquaresUnderEnemyAttack(bg, false);

		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++)
			{
				if (bg[ii][jj].getType() != ChessGUI.KING)
				{
					continue;
				}
				if (bg[ii][jj].getColor() != kingOfInterestColor)
				{
					continue;
				}

				if (enemyAttack[ii][jj])
				{
					return true;
				}
			}
		}
		return false;
	}

	public boolean underCheckAtPos(Piece[][] bg, int kingOfInterestColor, int col, int row)
	{
		boolean[][] enemyAttack = getAllSquaresUnderEnemyAttack(bg, false);

		if (bg[col][row].getType() != ChessGUI.KING)
		{
			return false;
		}
		if (bg[col][row].getColor() != kingOfInterestColor)
		{
			return false;
		}

		if (enemyAttack[col][row])
		{
			return true;
		}

		return false;
	}

}
