package vad;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

public class AI extends Player
{
	Piece[][]		playersLocalPieces	= new Piece[8][8];
	private Random	rand				= new Random();

	public AI(int playerColor)
	{
		super(playerColor);
	}

	@Override
	public void runMove(Piece[][] bg)
	{
		System.out.println("Running AI movement for class: " + this);
		updateLocalPieces(bg);
		runRandomMovement(bg);
	}

	public void runRandomMovement(Piece[][] bg)
	{
		System.out.println("Running random AI movement");
		boolean hasAtLeastOneMove = false;

		Piece pieceToMove = null;
		boolean[][] moves = new boolean[8][8];
		ArrayList<Point> possibleMoves = null;
		int randCol = -1, randRow = -1;

		while (!hasAtLeastOneMove)
		{
			randCol = rand.nextInt(8);
			randRow = rand.nextInt(8);

			pieceToMove = playersLocalPieces[randCol][randRow];
			moves = pieceToMove.getPossibleMoves(bg);
			possibleMoves = new ArrayList<Point>();

			for (int i = 0; i < 8; i++)
			{
				for (int j = 0; j < 8; j++)
				{
					if (moves[i][j])
					{
						possibleMoves.add(new Point(i, j));
						hasAtLeastOneMove = true;
					}
				}
			}
		}

		Point randomMove = possibleMoves.get(rand.nextInt(possibleMoves.size()));
		System.out.println("Moving to " + randomMove);
		Piece selectedPiece = bg[randomMove.x][randomMove.y];
		
		movePiece(selectedPiece, bg, randCol, randRow);
	}

	public void movePiece(Piece pieceToMove, Piece[][] bg, int destinationCol, int destinationRow)
	{
		pieceToMove.destroyPiece();
		pieceToMove.setPieceIcon(bg[destinationCol][destinationRow].getPieceIcon());
		pieceToMove.setType(bg[destinationCol][destinationRow].getType());
		pieceToMove.setColor(bg[destinationCol][destinationRow].getColor());

		bg[destinationCol][destinationRow].destroyPiece();
	}

	public void updateLocalPieces(Piece[][] bg)
	{
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (bg[i][j].getColor() == getColor())
				{
					playersLocalPieces[i][j] = bg[i][j];
				}
				else
					playersLocalPieces[i][j] = new Piece(new JButton(), Color.white);
			}
		}
	}

}
