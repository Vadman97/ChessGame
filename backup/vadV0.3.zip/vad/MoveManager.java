package vad;

import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class MoveManager
{
	public static void printPossibleMoves(boolean[][] possibleMoves)
	{
		System.out.println("Possible moves: ");
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				System.out.print(possibleMoves[i][j] ? 1 : 0 + ", ");
			}
		}
		System.out.println();
	}

	public int			player1Color, player2Color;
	public int			lastMoveBy;

	public int			firstMoveBy;
	public int			secondMoveBy;
	public boolean		gameRunning	= false;

	public boolean		aiEnemy		= true;

	private Image[][]	chessPieceImages;

	public Player[]		players		= new Player[2];

	public MoveManager(int player1Color, int player2Color, int firstMoveBy, Image[][] chessImgs)
	{
		// ///BE CAREFUL WITH COLOR CONSTANTS!!! WHITE IS 1!
		this.player1Color = player1Color;
		this.player2Color = player2Color;
		this.firstMoveBy = firstMoveBy;
		gameRunning = true;
		if (this.firstMoveBy == ChessGUI.BLACK)
		{
			lastMoveBy = ChessGUI.WHITE;
			secondMoveBy = ChessGUI.WHITE;
		}
		if (this.firstMoveBy == ChessGUI.WHITE)
		{
			lastMoveBy = ChessGUI.BLACK;
			secondMoveBy = ChessGUI.BLACK;
		}
		chessPieceImages = chessImgs;
		players[firstMoveBy] = new Player(player1Color);
		// this.players[this.lastMoveBy] = new Player(player2Color);
		players[lastMoveBy] = new AI(player2Color);
		if (firstMoveBy == ChessGUI.WHITE)
		{
			ChessGUI.turnIndicator.setText("Turn: " + "White");
		}
		else
		{
			ChessGUI.turnIndicator.setText("Turn: " + "Black");
		}
	}

	public void clearActivePossibleMoves(Piece[][] board)
	{
		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++)
			{
				if (board[ii][jj].getType() == -1)
				{
					board[ii][jj].destroyPiece();
				}
				else
				{
					board[ii][jj].setPieceIcon(new ImageIcon(chessPieceImages[board[ii][jj].getColor()][board[ii][jj].getType()]));
					board[ii][jj].getPieceSquareButton().setBackground(board[ii][jj].getBlankSquareColor());
				}
			}
		}
	}

	public void displayPossibleMoves(boolean[][] possibleMoves, Piece[][] board)
	{
		System.out.println("Printing possible moves: ");
		for (int ii = 0; ii < 8; ii++)
		{
			for (int jj = 0; jj < 8; jj++) // row
			{
				if (possibleMoves[ii][jj] == false)
				{
					continue;
				}
				// board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				board[ii][jj].getPieceSquareButton().setBackground(Color.green);
				System.out.println(ii + " " + jj);
			}
		}
	}

	public void displayPossibleMoves(Piece selectedPiece, Piece[][] board)
	{
		if (selectedPiece.isValidPiece())
		{
			boolean[][] possibleMoves = selectedPiece.getPossibleMoves(board);
			for (int ii = 0; ii < 8; ii++)
			{
				for (int jj = 0; jj < 8; jj++) // row
				{
					if (possibleMoves[ii][jj] == false)
					{
						continue;
					}
					board[ii][jj].getPieceSquareButton().setBackground(Color.green);
					// board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				}
			}
		}
	}

	public void displaySquaresUnderEnemyAttack(Piece selectedPiece, Piece[][] board)
	{
		if (selectedPiece.isValidPiece())
		{
			boolean[][] underEAttack = selectedPiece.getAllSquaresUnderEnemyAttack(board, true);
			for (int ii = 0; ii < 8; ii++)
			{
				for (int jj = 0; jj < 8; jj++) // row
				{
					if (underEAttack[ii][jj] == false)
					{
						continue;
					}
					board[ii][jj].getPieceSquareButton().setBackground(Color.green);
					// board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				}
			}
		}
	}

	public void enemyCheckPopup()
	{
		Piece p = new Piece(new JButton(), Color.white);
		p.setColor(lastMoveBy);
		underCheckPopupMessage(p, lastMoveBy);
	}

	public int getActiveColor()
	{
		if (lastMoveBy == ChessGUI.BLACK)
		{
			return ChessGUI.WHITE;
		}
		if (lastMoveBy == ChessGUI.WHITE)
		{
			return ChessGUI.BLACK;
		}
		return -1;
	}

	public boolean isGameOver(Piece selectedPiece)
	{
		if (selectedPiece.checkMate(ChessGUI.getBoardGrid(), ChessGUI.WHITE, false))
		{
			JOptionPane.showMessageDialog(ChessGUI.gui, "CHECKMATE BLACK WINS");
			ChessGUI.turnIndicator.setText("BLACK WINS");
			gameRunning = false;
			return true;
		}
		if (selectedPiece.checkMate(ChessGUI.getBoardGrid(), ChessGUI.BLACK, false))
		{
			JOptionPane.showMessageDialog(ChessGUI.gui, "CHECKMATE WHITE WINS");
			ChessGUI.turnIndicator.setText("WHITE WINS");
			gameRunning = false;
			return true;
		}
		return false;
	}

	public void processMove(Piece selectedPiece, Piece[][] board) // runs on square clicked
	{
		if (!gameRunning)
		{
			return;
		}
		int currentTurn;
		if (lastMoveBy == ChessGUI.BLACK)
		{
			currentTurn = ChessGUI.WHITE;
		}
		else
		{
			currentTurn = ChessGUI.BLACK;
		}

		if (isGameOver(selectedPiece))
		{
			return;
		}

		if (currentTurn != firstMoveBy)
		{
			if (aiEnemy)
			{
				System.out.println("===================================");
				players[currentTurn].runMove(board);

				enemyCheckPopup();

				updateTurn();

				updateTurnText();
				ChessGUI.tools.updateUI();
				ChessGUI.gui.updateUI();

				return;
			}
		}

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		if (ChessGUI.displayAttackSqDEBUG)
		{
			clearActivePossibleMoves(board);
			displaySquaresUnderEnemyAttack(selectedPiece, board);
			return;
		}

		if (!players[currentTurn].hasSelectedPiece()) // if player doesnt have piece selected
		{

			if (!selectedPiece.isValidPiece())
			{
				return; // if square clicked is valid
			}

			if (selectedPiece.getColor() != players[currentTurn].getColor()) // if piece clicked is of player's color
			{
				clearActivePossibleMoves(board);
				System.out.println("ERROR Player pressed on enemy piece");
				return;
			}

			boolean[][] possibleMoves = selectedPiece.getPossibleMoves(board);

			players[currentTurn].selectPiece(selectedPiece);
			clearActivePossibleMoves(board);
			this.displayPossibleMoves(possibleMoves, board);
		}
		else
		// else if the players already has a piece selected, need to set new clicked square to piece selected
		{
			clearActivePossibleMoves(board);
			boolean[][] possibleMoves = players[currentTurn].getSelectedPiece().getPossibleMoves(board);
			if (possibleMoves[selectedPiece.getColumn()][selectedPiece.getRow()]) // valid move location
			{
				System.out.println("Player with selected piece clicked on VALID square, need to MOVE PIECE");

				// players[currentTurn].getSelectedPiece() needs to be at selectedPiece
				selectedPiece.destroyPiece();
				selectedPiece.setPieceIcon(players[currentTurn].getSelectedPiece().getPieceIcon());
				selectedPiece.setType(players[currentTurn].getSelectedPiece().getType());
				selectedPiece.setColor(players[currentTurn].getSelectedPiece().getColor());

				players[currentTurn].getSelectedPiece().destroyPiece();
				players[currentTurn].deselectPiece();

				enemyCheckPopup();

				updateTurn();

				updateTurnText();

				if (aiEnemy)
				{
					if (lastMoveBy == players[firstMoveBy].getColor())
					{
						players[secondMoveBy].runMove(board);
						updateTurn();
					}
				}
			}
			else
			// invalid move location, deselect
			{
				System.out.println("Player with selected piece clicked on INVALID square, need to deselect");
				System.out.println(selectedPiece.getColumn() + " " + selectedPiece.getRow());
				// TODO King under check, (? different state or something so that king must go out of check next move)
				// TODO Maybe put underCheck validation into kingMove?
				// TODO Piece cannot move if preventing check
				// TODO King super weird possibleMove patterns
				// this.printPossibleMoves(possibleMoves);

				players[currentTurn].deselectPiece();
				return;
			}
		}
		if (isGameOver(selectedPiece))
		{
			return;
		}

		updateTurnText();

		ChessGUI.tools.updateUI();
		ChessGUI.gui.updateUI();
	}

	public void updateTurn()
	{
		if (lastMoveBy == ChessGUI.BLACK)
		{
			lastMoveBy = ChessGUI.WHITE;
		}
		else if (lastMoveBy == ChessGUI.WHITE)
		{
			lastMoveBy = ChessGUI.BLACK;
		}
	}

	public void updateTurnText()
	{
		if (lastMoveBy == ChessGUI.WHITE)
		{
			ChessGUI.turnIndicator.setText("Turn: " + "Black");
		}
		else
		{
			ChessGUI.turnIndicator.setText("Turn: " + "White");
		}
	}

	public void underCheckPopupMessage(Piece selectedPiece, int currentTurn)
	{
		if (selectedPiece.underCheck(ChessGUI.getBoardGrid(), currentTurn, false))
		{
			JOptionPane.showMessageDialog(ChessGUI.gui, "CHECK");
		}
	}
}
