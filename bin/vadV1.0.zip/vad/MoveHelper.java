package vad;

import java.util.ArrayList;

public class MoveHelper
{
	public static class Position
	{
		int	col, row;

		public Position(int col, int row)
		{
			this.col = col;
			this.row = row;
		}
	}

	public static ArrayList<Position> getReachablePosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		// position.add(new Position(col, row));
		Piece p = board[col][row];
		switch (p.getType())
		{
			case Piece.ROOK:
				return getReachableRookPosition(board, col, row);
			case Piece.KNIGHT:
				return getReachableKnightPosition(board, col, row);
			case Piece.BISHOP:
				return getReachableBishopPosition(board, col, row);
		}

		return position;
	}

	private static ArrayList<Position> getReachableRookPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		for (int c = col - 1; c >= 0; c--)
		{
			if (!checkFreeAndAdd(board, position, c, row))
				break;
		}
		for (int c = col + 1; c < 8; c++)
		{
			if (!checkFreeAndAdd(board, position, c, row))
				break;
		}
		for (int r = row - 1; r >= 0; r--)
		{
			if (!checkFreeAndAdd(board, position, col, r))
				break;
		}
		for (int r = row + 1; r < 8; r++)
		{
			if (!checkFreeAndAdd(board, position, col, r))
				break;
		}
		return position;
	}

	private static ArrayList<Position> getReachableKnightPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		checkFreeAndAdd(board, position, col - 2, row - 1);
		checkFreeAndAdd(board, position, col - 2, row + 1);
		checkFreeAndAdd(board, position, col + 2, row - 1);
		checkFreeAndAdd(board, position, col + 2, row + 1);
		checkFreeAndAdd(board, position, col - 1, row - 2);
		checkFreeAndAdd(board, position, col - 1, row + 2);
		checkFreeAndAdd(board, position, col + 1, row - 2);
		checkFreeAndAdd(board, position, col + 1, row + 2);
		return position;
	}

	private static ArrayList<Position> getReachableBishopPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		for (int i = 1;; i++)
		{
			if (!checkFreeAndAdd(board, position, col + i, row + i))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeAndAdd(board, position, col - i, row + i))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeAndAdd(board, position, col - i, row - i))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeAndAdd(board, position, col + i, row - i))
				break;
		}
		return position;
	}

	private static boolean checkFree(Piece[][] board, int col, int row)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		return board[col][row] == null;
	}

	private static boolean checkFreeAndAdd(Piece[][] board, ArrayList<Position> arr, int col, int row)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		boolean ret = board[col][row] == null;
		if (ret)
		{
			arr.add(new Position(col, row));
		}
		return ret;
	}
}
