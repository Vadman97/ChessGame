package vad;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class NewChessGUI extends JFrame implements ActionListener
{

	PieceButton[][]						buttons				= new PieceButton[8][8];
	Piece[][]							board				= new Piece[8][8];

	public static final int[]			STARTING_ROW		=
															{ Piece.ROOK, Piece.KNIGHT, Piece.BISHOP, Piece.QUEEN, Piece.KING, Piece.BISHOP, Piece.KNIGHT, Piece.ROOK };
	public static final ImageIcon[][]	CHESS_PIECE_IMAGES	= new ImageIcon[2][6];
	static
	{
		try
		{
			URL url = new URL("http://i.stack.imgur.com/memI0.png");
			BufferedImage bi = ImageIO.read(url);
			for (int color = 0; color < 2; color++)
				for (int type = 0; type < 6; type++)
					CHESS_PIECE_IMAGES[color][type] = new ImageIcon(bi.getSubimage(type * 64, color * 64, 64, 64));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}

	public NewChessGUI()
	{
		JPanel gameBoard = new JPanel();
		gameBoard.setLayout(new GridLayout(8, 8));
		for (int row = 0; row < 8; row++)
		{
			for (int col = 0; col < 8; col++)
			{
				final PieceButton b = new PieceButton(null, col, row, (col + row) % 2 == 1 ? Color.BLACK : Color.WHITE);
				buttons[col][row] = b;
				b.addActionListener(this);
				b.addMouseListener(new MouseListener(){

					@Override
					public void mouseClicked(MouseEvent arg0)
					{
						if(arg0.getButton()==MouseEvent.BUTTON3){
							board[b.column][b.row]=null;
							updateBoard();
						}
					}

					@Override
					public void mouseEntered(MouseEvent arg0)
					{
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseExited(MouseEvent arg0)
					{
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mousePressed(MouseEvent arg0)
					{
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseReleased(MouseEvent arg0)
					{
						// TODO Auto-generated method stub
						
					}
					
				});
				gameBoard.add(b);
			}
		}
		for (int i = 0; i < 8; i++)
		{
			board[i][0] = Piece.allPieces[Piece.BLACK][STARTING_ROW[i]];
			board[i][7] = Piece.allPieces[Piece.WHITE][STARTING_ROW[i]];
			board[i][1] = Piece.allPieces[Piece.BLACK][Piece.PAWN];
			board[i][6] = Piece.allPieces[Piece.WHITE][Piece.PAWN];
		}
		updateBoard();

		add(gameBoard);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	private void updateBoard()
	{
		for (int row = 0; row < 8; row++)
		{
			for (int col = 0; col < 8; col++)
			{
				if (buttons[col][row].getPiece() != board[col][row])
				{
					buttons[col][row].setPiece(board[col][row]);
				}
			}
		}
	}

	public static void main(String[] args)
	{
		new NewChessGUI();
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		PieceButton button = (PieceButton) e.getSource();
		int col = button.getColumn();
		int row = button.getRow();

		ArrayList<MoveHelper.Position> positions=MoveHelper.getReachablePosition(board, col, row);
		for(MoveHelper.Position p:positions){
			buttons[p.col][p.row].markReachable(true);
		}
	}
}
