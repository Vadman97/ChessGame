package vad;

public class Player
{
	private Piece	selectedPiece;
	private int		playerColor;

	public Player(int playerColor)
	{
		this.playerColor = playerColor;
		this.selectedPiece = null;
	}

	public void deselectPiece()
	{
		this.selectedPiece = null;
	}

	public int getColor()
	{
		return this.playerColor;
	}

	public Piece getSelectedPiece()
	{
		return this.selectedPiece;
	}

	public boolean hasSelectedPiece()
	{
		if (this.selectedPiece == null) return false;
		if (!this.selectedPiece.isValidPiece()) return false;
		return true;
	}

	public void selectPiece(Piece select)
	{
		this.selectedPiece = select;
	}

	public void runMove(Piece[][] board)
	{
		System.out.println("Running default movement for class: " + this);
	}
}
