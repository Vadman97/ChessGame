package vad;

public class Move
{
	private Piece start = null;
	private Piece destination = null;
	
	public Move(Piece start, Piece dest)
	{
		this.start = start;
		this.destination = dest;
	}
	

	public Piece getStartPiece()
	{
		return start;
	}
	
	public Piece getDestinationPiece()
	{
		return destination;
	}
}
