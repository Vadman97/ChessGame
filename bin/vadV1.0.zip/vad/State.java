package vad;

import java.awt.Color;

public class State implements Comparable<State>
{
	public Piece[][]	realOriginalBoard;
	public Move			move;
	private int			score		= 0;
	public int			playerColor;
	public int			opponentColor;
	private State[]		children	= new State[0];

	// maybe add local move

	public State(int playerColor, Piece[][] board, Move mov)
	{
		this.realOriginalBoard = board;
		this.playerColor = playerColor;
		if (this.playerColor == ChessGUI.BLACK)
			opponentColor = ChessGUI.WHITE;
		if (this.playerColor == ChessGUI.WHITE)
			opponentColor = ChessGUI.BLACK;
		move = mov;
	}

	public State[] getChildren()
	{
		return children;
	}

	public State[] initializeChildren()
	{
		// System.out.println("**************RUNNING INITIALIZE CHILDREN");
		Move[] moves = Piece.getAllPossibleMoves(realOriginalBoard, playerColor);
		State[] states = new State[moves.length];
		for (int i = 0; i < moves.length; i++)
		{
			Piece[][] newBoard = new Piece[8][8];
			for (int ii = 0; ii < 8; ii++)
			{
				for (int jj = 0; jj < 8; jj++)
				{
					newBoard[ii][jj] = new Piece(null, Color.white);
					newBoard[ii][jj].setType(realOriginalBoard[ii][jj].getType());
					newBoard[ii][jj].setColor(realOriginalBoard[ii][jj].getColor());
					newBoard[ii][jj].setPos(realOriginalBoard[ii][jj].getColumn(), realOriginalBoard[ii][jj].getRow());
				}
			}

			MoveManager.makeMove(newBoard, moves[i]);
			states[i] = new State(opponentColor, newBoard, moves[i]);
		}
		return states;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int score)
	{
		this.score = score;
	}

	@Override
	public int compareTo(State other)
	{
		return this.getScore() - other.getScore();
	}
}
