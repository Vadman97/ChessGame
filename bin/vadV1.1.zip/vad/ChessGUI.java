package vad;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.MouseInputListener;

public class ChessGUI implements ActionListener, KeyListener, MouseInputListener
{

	public static final ImageIcon[][]			chessPieceImages		= new ImageIcon[2][6];
	static{
		try
		{
			URL url = new URL("http://i.stack.imgur.com/memI0.png");
			BufferedImage bi = ImageIO.read(url);
			for (int color = 0; color < 2; color++)
				for (int type = 0; type < 6; type++)
					chessPieceImages[color][type] = new ImageIcon(bi.getSubimage(type * 64, color * 64, 64, 64));
		} catch (Exception e){
			e.printStackTrace();
			System.exit(1);
		}
	}
	

	public static final JPanel	gui						= new JPanel(new BorderLayout(3, 3));
	// private JButton[][] chessBoardSquares = new JButton[8][8];
	
	private static PieceButton[][]	pieces					= new PieceButton[8][8];
	private static Piece[][] gameBoard=new Piece[8][8];
	// [column][row] ^
	public static JPanel		chessBoard;
	private final JLabel		message					= new JLabel("Ready!");
	private static final String	COLS					= "ABCDEFGH";
	public static final int		QUEEN					= 1, KING = 0, ROOK = 2, KNIGHT = 3, BISHOP = 4, PAWN = 5;
	public static final int[]	STARTING_ROW			=
														{ ChessGUI.ROOK, ChessGUI.KNIGHT, ChessGUI.BISHOP, ChessGUI.QUEEN, ChessGUI.KING, ChessGUI.BISHOP, ChessGUI.KNIGHT, ChessGUI.ROOK };
	public static final int		BLACK					= 0, WHITE = 1;
	public static boolean		deletePieceModeDEBUG	= false;
	public static boolean		addPieceDEBUG			= false;
	public static boolean		displayAttackSqDEBUG	= false;
	public static MoveManager	moveManager				= null;
	public static JToolBar		tools					= new JToolBar();
	public static JButton		turnIndicator			= new JButton();

	/*
	 * TODO!!!!!!!!!!!!! Piece protected evaluation King can always attack left
	 * and down? maybe... also pawns potentially do not affect king? TODO Add
	 * logging for program runs through vadweb
	 * TODO GAME FREEZES ON TIE WHEN KING CANT MOVE
	 */
	public static Piece[][] getBoardGrid()
	{
		return ChessGUI.gameBoard;
	}

	public static void main(String[] args)
	{
		Runnable r = new Runnable()
		{

			@Override
			public void run()
			{
				ChessGUI cg = new ChessGUI();

				JFrame f = new JFrame("ChessChamp");
				f.add(cg.getGui());
				// Ensures JVM closes after frame(s) closed and
				// all non-daemon threads are finished
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				// See http://stackoverflow.com/a/7143398/418556 for demo.
				f.setLocationByPlatform(true);

				// ensures the frame is the minimum size it needs to be
				// in order display the components within it
				f.pack();
				// ensures the minimum size is enforced.
				f.setMinimumSize(f.getSize());
				f.setVisible(true);
				System.out.println("Ran run!");
			}
		};
		// Swing GUIs should be created and updated on the EDT
		// http://docs.oracle.com/javase/tutorial/uiswing/concurrency
		SwingUtilities.invokeLater(r);
	}

	public ChessGUI()
	{
		this.initializeGui();
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		PieceButton button=(PieceButton)e.getSource();
		int col=button.getColumn();
		int row=button.getRow();
	
		if (ChessGUI.moveManager != null) ChessGUI.moveManager.processMove(ChessGUI.pieces[col][row], ChessGUI.pieces);

		if (ChessGUI.deletePieceModeDEBUG) ChessGUI.pieces[col][row].setPiece(null);

		if (ChessGUI.addPieceDEBUG)
		{
			ChessGUI.pieces[col][row].setPiece(Piece.allPieces[ChessGUI.BLACK][ChessGUI.QUEEN]);
		}

		ChessGUI.gui.updateUI(); // IMPORTANT TO REFRESH GRID
	}

	public final JComponent getGui()
	{
		return ChessGUI.gui;
	}

	public final void initializeGui()
	{
		// create the images for the chess pieces
		// set up the main GUI
		ChessGUI.gui.setBorder(new EmptyBorder(5, 5, 5, 5));
		ChessGUI.tools.setFloatable(false);
		ChessGUI.gui.add(ChessGUI.tools, BorderLayout.PAGE_START);
		ChessGUI.turnIndicator.setText("Turn Indicator");

		Action DEBUGToggleAttackSquares = new AbstractAction("Attack Sq")
		{
			private static final long	serialVersionUID	= -5929616858105243416L;

			@Override
			public void actionPerformed(ActionEvent e)
			{
				ChessGUI.displayAttackSqDEBUG = !ChessGUI.displayAttackSqDEBUG;
			}
		};

		Action DEBUGAddPieceToggle = new AbstractAction("Spawn Piece")
		{
			private static final long	serialVersionUID	= -5929616858105243416L;

			@Override
			public void actionPerformed(ActionEvent e)
			{
				ChessGUI.addPieceDEBUG = !ChessGUI.addPieceDEBUG;
			}
		};

		Action DEBUGPieceDeleteToggle = new AbstractAction("Delete Piece")
		{
			private static final long	serialVersionUID	= -5929616858105243416L;

			@Override
			public void actionPerformed(ActionEvent e)
			{
				ChessGUI.deletePieceModeDEBUG = !ChessGUI.deletePieceModeDEBUG;
			}
		};

		Action newGameAction = new AbstractAction("New")
		{
			private static final long	serialVersionUID	= -5929616858105243416L;

			@Override
			public void actionPerformed(ActionEvent e)
			{
				ChessGUI.this.setupNewGame();
			}
		};
		ChessGUI.tools.add(newGameAction);
		ChessGUI.tools.add(new JButton("Save")); // TODO - add functionality!
		ChessGUI.tools.add(new JButton("Restore")); // TODO - add functionality!
		ChessGUI.tools.addSeparator();
		ChessGUI.tools.add(new JButton("Resign")); // TODO - add functionality!
		ChessGUI.tools.add(ChessGUI.turnIndicator);
		ChessGUI.tools.addSeparator();
		ChessGUI.tools.add(DEBUGPieceDeleteToggle);
		ChessGUI.tools.add(DEBUGAddPieceToggle);
		ChessGUI.tools.add(DEBUGToggleAttackSquares);
		ChessGUI.tools.addSeparator();
		ChessGUI.tools.add(this.message);

		ChessGUI.gui.add(new JLabel("?"), BorderLayout.LINE_START);

		ChessGUI.chessBoard = new JPanel(new GridLayout(0, 9))
		{
			private static final long	serialVersionUID	= -2092792667329990596L;

			/**
			 * Override the preferred size to return the largest it can, in a
			 * square shape. Must (must, must) be added to a GridBagLayout as
			 * the only component (it uses the parent as a guide to size) with
			 * no BagConstaint (so it is centered).
			 */
			@Override
			public final Dimension getPreferredSize()
			{
				Dimension d = super.getPreferredSize();
				Dimension prefSize = null;
				Component c = this.getParent();
				if (c == null)
					prefSize = new Dimension((int) d.getWidth(), (int) d.getHeight());
				else if ((c != null) && (c.getWidth() > d.getWidth()) && (c.getHeight() > d.getHeight()))
					prefSize = c.getSize();
				else
					prefSize = d;
				int w = (int) prefSize.getWidth();
				int h = (int) prefSize.getHeight();
				// the smaller of the two sizes
				int s = (w > h ? h : w);
				return new Dimension(s, s);
			}
		};
		ChessGUI.chessBoard.setBorder(new CompoundBorder(new EmptyBorder(8, 8, 8, 8), new LineBorder(Color.BLACK)));
		// Set the BG to be ochre
		Color ochre = new Color(204, 119, 34);
		ChessGUI.chessBoard.setBackground(ochre);
		JPanel boardConstrain = new JPanel(new GridBagLayout());
		boardConstrain.setBackground(ochre);
		boardConstrain.add(ChessGUI.chessBoard);
		ChessGUI.gui.add(boardConstrain);

		this.processChessBoardSquares();
	}

	@Override
	public void keyPressed(KeyEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	public void processChessBoardSquares()
	{
		ChessGUI.chessBoard.removeAll();

		for (int ii = 0; ii < ChessGUI.pieces.length; ii++)
			for (int jj = 0; jj < ChessGUI.pieces[ii].length; jj++)
				ChessGUI.pieces[ii][jj] = null;
		// create the chess board squares
		Insets buttonMargin = new Insets(0, 0, 0, 0);
		for (int ii = 0; ii < ChessGUI.pieces.length; ii++)
			for (int jj = 0; jj < ChessGUI.pieces[ii].length; jj++) // col
			{
				boolean temp = false;
				JButton b = new JButton();
				b.setMargin(buttonMargin);
				// our chess pieces are 64x64 px in size, so we'll
				// 'fill this in' using a transparent icon..
				ImageIcon icon = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
				b.setIcon(icon);
				if ((((jj % 2) == 1) && ((ii % 2) == 1))
				// ) {
						|| (((jj % 2) == 0) && ((ii % 2) == 0)))
				{
					temp = true;
					b.setBackground(Color.WHITE);
				} else
					b.setBackground(Color.BLACK);
				b.setActionCommand(jj + "|" + ii);
				b.addActionListener(this);
				if (temp)
					ChessGUI.pieces[jj][ii] = new Piece(b, Color.WHITE);
				else
					ChessGUI.pieces[jj][ii] = new Piece(b, Color.BLACK);
			}

		/*
		 * fill the chess board
		 */
		ChessGUI.chessBoard.add(new JLabel(""));
		// fill the top row
		for (int ii = 0; ii < 8; ii++)
			ChessGUI.chessBoard.add(new JLabel(ChessGUI.COLS.substring(ii, ii + 1), SwingConstants.CENTER));
		// fill the black non-pawn piece row
		for (int ii = 0; ii < 8; ii++)
			for (int jj = 0; jj < 8; jj++)
				switch (jj)
				{
					case 0:
						ChessGUI.chessBoard.add(new JLabel("" + (9 - (ii + 1)), SwingConstants.CENTER));
					default:
						ChessGUI.chessBoard.add(ChessGUI.pieces[jj][ii].getPieceSquareButton());
						ChessGUI.pieces[jj][ii].setPos(jj, ii);
						break;
				}

		ChessGUI.gui.updateUI(); // IMPORTANT TO REFRESH GRID
	}

	/**
	 * Initializes the icons of the initial chess board piece places
	 */
	private final void setupNewGame()
	{
		System.out.println("Setting up new game!");
		this.message.setText("Make your move!");

		this.processChessBoardSquares();

		// set up the black pieces
		// ii is col second is row
		for (int ii = 0; ii < ChessGUI.STARTING_ROW.length; ii++)
		{
			ChessGUI.pieces[ii][0].setPieceIcon(new ImageIcon(this.chessPieceImages[ChessGUI.BLACK][ChessGUI.STARTING_ROW[ii]]));
			ChessGUI.pieces[ii][0].setType(ChessGUI.STARTING_ROW[ii]);
			ChessGUI.pieces[ii][0].setColor(ChessGUI.BLACK);
			ChessGUI.pieces[ii][0].setPos(ii, 0);
		}
		for (int ii = 0; ii < ChessGUI.STARTING_ROW.length; ii++)
		{
			ChessGUI.pieces[ii][1].setPieceIcon(new ImageIcon(this.chessPieceImages[ChessGUI.BLACK][ChessGUI.PAWN]));
			ChessGUI.pieces[ii][1].setType(ChessGUI.PAWN);
			ChessGUI.pieces[ii][1].setColor(ChessGUI.BLACK);
			ChessGUI.pieces[ii][1].setPos(ii, 1);
		}
		// set up the white pieces
		for (int ii = 0; ii < ChessGUI.STARTING_ROW.length; ii++)
		{
			ChessGUI.pieces[ii][6].setPieceIcon(new ImageIcon(this.chessPieceImages[ChessGUI.WHITE][ChessGUI.PAWN]));
			ChessGUI.pieces[ii][6].setType(ChessGUI.PAWN);
			ChessGUI.pieces[ii][6].setColor(ChessGUI.WHITE);
			ChessGUI.pieces[ii][6].setPos(ii, 6);
		}
		for (int ii = 0; ii < ChessGUI.STARTING_ROW.length; ii++)
		{
			ChessGUI.pieces[ii][7].setPieceIcon(new ImageIcon(this.chessPieceImages[ChessGUI.WHITE][ChessGUI.STARTING_ROW[ii]]));
			ChessGUI.pieces[ii][7].setType(ChessGUI.STARTING_ROW[ii]);
			ChessGUI.pieces[ii][7].setColor(ChessGUI.WHITE);
			ChessGUI.pieces[ii][7].setPos(ii, 7);
		}

		ChessGUI.moveManager = new MoveManager(ChessGUI.WHITE, ChessGUI.BLACK, ChessGUI.WHITE, this.chessPieceImages);
	}
}