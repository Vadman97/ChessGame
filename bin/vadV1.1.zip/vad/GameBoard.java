package vad;

import java.util.ArrayList;

public class GameBoard
{
	Piece[][]					board;
	int currentColor= Piece.WHITE;
	public static final int[]	STARTING_ROW	=
												{ Piece.ROOK, Piece.KNIGHT, Piece.BISHOP, Piece.QUEEN, Piece.KING, Piece.BISHOP, Piece.KNIGHT, Piece.ROOK };

	public GameBoard()
	{
		board = new Piece[8][8];
		for (int i = 0; i < 8; i++)
		{
			board[i][0] = Piece.allPieces[Piece.BLACK][STARTING_ROW[i]];
			board[i][7] = Piece.allPieces[Piece.WHITE][STARTING_ROW[i]];
			board[i][1] = Piece.allPieces[Piece.BLACK][Piece.PAWN];
			board[i][6] = Piece.allPieces[Piece.WHITE][Piece.PAWN];
		}
	}

	public Piece getPiece(int col, int row)
	{
		return board[col][row];
	}

	public void removePiece(int column, int row)
	{
		setPiece(column, row, null);
	}

	public void setPiece(int col, int row, Piece piece)
	{
		board[col][row] = piece;
	}

	public boolean isEmpty(int col, int row)
	{
		return board[col][row] == null;
	}

	public Piece getPiece(Position dest)
	{
		return getPiece(dest.col, dest.row);
	}

	public void setPiece(Position pos, Piece piece)
	{
		board[pos.col][pos.row] = piece;
	}

	public void apply(Move m)
	{
		Position p = m.getStartPosition();
		Piece piece = getPiece(p);
		setPiece(p, null);
		setPiece(m.getDestPosition(), piece);
		//System.out.println("Move apply: " + m.getKilledPiece());
		currentColor=currentColor==Piece.WHITE?Piece.BLACK:Piece.WHITE;
	}

	public void undo(Move move)
	{
		setPiece(move.getStartPosition(), getPiece(move.getDestPosition()));
		setPiece(move.getDestPosition(), move.getKilledPiece());
		//System.out.println("Move undo: " + move.getKilledPiece());
		currentColor=currentColor==Piece.WHITE?Piece.BLACK:Piece.WHITE;
	}

	public ArrayList<Move> getAllPossibleMovesWithoutValidation(int color)
	{
		ArrayList<Move> moves = new ArrayList<>();
		for (int r = 0; r < 8; r++)
		{
			for (int c = 0; c < 8; c++)
			{
				if(isEmpty(c, r))continue;
				if (getPiece(c, r).getColor() == color)
				{
					moves.addAll(MoveHelper.getAllMoves4PieceWithoutValidation(this, Position.get(c, r)));
				}
			}
		}
		return moves;
	}
	
	public ArrayList<Move> getAllPossibleMoves(int color)
	{
		ArrayList<Move> moves = new ArrayList<>();
		for (int r = 0; r < 8; r++)
		{
			for (int c = 0; c < 8; c++)
			{
				if(isEmpty(c, r))continue;
				if (getPiece(c, r).getColor() == color)
				{
					moves.addAll(MoveHelper.getAllMoves4Piece(this, Position.get(c, r)));
				}
			}
		}
		return moves;
	}

	public boolean isCheck(int kingColor)
	{
		for (Move m : getAllPossibleMovesWithoutValidation(kingColor == Piece.WHITE ? Piece.BLACK : Piece.WHITE))
		{
			if (m.getKilledPiece()!=null&&m.getKilledPiece().getType() == Piece.KING)
			{
				return true;
			}
		}
		return false;
	}

	public boolean isCheckMate(int kingColor)
	{
		if (isCheck(kingColor))
		{
			if (getAllPossibleMovesWithValidation(kingColor).size() == 0)
				return true;
		}
		return false;
	}

	private ArrayList<Move> getAllPossibleMovesWithValidation(int kingColor)
	{
		
		return null;
	}

	public boolean isEmpty(Position pos)
	{
		return board[pos.col][pos.row]==null;
	}
}
