package vad;

import java.awt.Point;
import java.util.ArrayList;

public class Moves_OLD
{
	private boolean[][]			possibleDest	= new boolean[8][8];
	//private Piece[][]			board;
	private Piece				start			= null;
	private ArrayList<Point>	destinations	= new ArrayList<Point>();
	private Point				startLoc		= new Point();

	// public HashMap<Piece, HashMap<Point, Integer>> scoreMap = new HashMap<Piece, HashMap<Point, Integer>>();
	// public HashMap<Point, Integer> scoreMap = new HashMap<Point, Integer>();

	public Moves_OLD(Piece m, Piece[][] board)
	{
		//this.board = board;
		start = m;
		startLoc.x = start.getColumn();
		startLoc.y = start.getRow();
		possibleDest = start.getPossibleMoves(board);

		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (possibleDest[i][j])
				{
					destinations.add(new Point(i, j));
				}
			}
		}

		//evaluatePieceScore();
	}

	/*private void evaluatePieceScore()
	{
		// int pieceType = start.getType();
		// int pieceColor = start.getColor();

		for (Point p : destinations)
		{
			
			
			 * int score = 0; // CALCULATE HEURISTIC Piece temp = new Piece(new JButton(), Color.white); temp.setType(start.getType()); temp.setColor(start.getColor()); temp.setPos(p.x, p.y); if (temp.isProtected(board)) { score += 10; } else { score -= 10; }
			 
		}
		ArrayList<vad.State> states = new ArrayList<vad.State>();

		State start = new State(Piece[][] board,);
	}*/
}
