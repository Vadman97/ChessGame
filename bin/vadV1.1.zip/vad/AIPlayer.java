package vad;

public class AIPlayer implements Player
{
	//NewChessGUI	gui;
	int playerColor;
	int depth = 4;
	
	public AIPlayer(int playerColor)
	{
		this.playerColor = playerColor;
		//gui = new NewChessGUI(null);
		//gui.setTitle("Chess - Played by AI");
	}

	@Override
	public Move makeMove(GameBoard board)
	{
		long start = System.currentTimeMillis();
		Move move = getBestMove(board, depth);
		long end = System.currentTimeMillis();
		System.out.println((end-start)/1000.);
		return move;
		//return b.getAllPossibleMoves(playerColor).get(0);
	}

	@Override
	public void update(GameBoard board)
	{
		//gui.updateBoard(board);
	}
	
	public int minimax(GameBoard board, int d)
	{
		if (d == 0)
		{
			return evaluateBoard(board);
		}
		if (board.currentColor == playerColor)
		{
			int maxScore = Integer.MIN_VALUE;
			for (Move child : board.getAllPossibleMoves(board.currentColor))
			{
				board.apply(child);
				int score = minimax(board, d - 1);
				board.undo(child);
				if (score > maxScore)
					maxScore = score;
			}
			return maxScore;
		}
		else
		{
			int minScore = Integer.MAX_VALUE;
			for (Move child : board.getAllPossibleMoves(board.currentColor))
			{
				board.apply(child);
				int score = minimax(board, d - 1);
				board.undo(child);
				if (score < minScore)
					minScore = score;
			}
			return minScore;
		}
	}

	public Move getBestMove(GameBoard board, int d)
	{
		int maxScore = Integer.MIN_VALUE;
		Move best = null;
		for (Move child : board.getAllPossibleMoves(board.currentColor))
		{
			board.apply(child);
			int score = minimax(board, d - 1);
			board.undo(child);
			if (score > maxScore)
			{
				maxScore = score;
				best = child;
			}
		}
		return best;
	}
	
	public int evaluateBoard(GameBoard board)
	{
		int score = 0;
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (board.currentColor == playerColor)
				{
					
					/*if (s.realOriginalBoard[i][j].isProtected(s.realOriginalBoard))
					{
						score += 10;
					}*/
					// if can kill, good
					// for each piece close to king, good
					// if can kill better piece very good
				}
				else
				{
					/*if (s.realOriginalBoard[i][j].isProtected(s.realOriginalBoard))
					{
						score -= 3;
					}*/
				}

			}
		}
		return score;
	}
}
