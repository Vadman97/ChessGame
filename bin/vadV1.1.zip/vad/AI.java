package vad;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

public class AI extends Player
{
	Piece[][]		playersLocalPieces	= new Piece[8][8];
	private Random	rand				= new Random();
	private int		depth				= 2;

	public AI(int playerColor)
	{
		super(playerColor);
	}

	public Piece[][] getAllMoveablePieces(Piece[][] bg)
	{
		updateLocalPieces(bg);
		Piece[][] moveable = new Piece[8][8];
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				moveable[i][j] = new Piece(new JButton(), Color.white);
				boolean[][] moves = playersLocalPieces[i][j].getPossibleMoves(bg);

				boolean hasAtLeastOneMove = false;
				for (int ii = 0; ii < 8; ii++)
				{
					for (int jj = 0; jj < 8; jj++)
					{
						if (moves[ii][jj])
						{
							hasAtLeastOneMove = true;
							break;
						}
					}
					if (hasAtLeastOneMove)
					{
						break;
					}
				}

				if (hasAtLeastOneMove)
				{
					moveable[i][j] = playersLocalPieces[i][j];
				}
			}
		}
		return moveable;
	}

	public void runSmartMovement(Piece[][] bg)
	{
		State start = new State(getColor(), bg, null);
		//System.out.println("^^^^^^^^^^ADDING CHILDREN^^^^^^^^^^^^");
		//addChildren(start, depth);
		//System.out.println("^^^^^^^^^^DONE ADDING CHILDREN^^^^^^^^^^^^");
		System.out.println("^^^^^^^^^^MINIMAX EVALUATION START^^^^^^^^^^^^");
		// minimax(start, depth);

		// Move mov = start.getChildren()[start.getChildren().length - 1].move;
		Move mov = getBestMove(start, depth).move;
		System.out.println("^^^^^^^^^^MINIMAX EVALUATION COMPLETE^^^^^^^^^^^^");

		MoveManager.makeMove(ChessGUI.getBoardGrid(), mov);
		System.out.println("^^^^^^^^^^DONE^^^^^^^^^^^^");
	}

	public int minimax(State s, int d)
	{
		if (d == 0)
		{
			return evaluateBoard(s);
		}
		if (s.playerColor == getColor())
		{
			int maxScore = Integer.MIN_VALUE;
			for (State child : addChildren(s))
			{
				int score = minimax(child, d - 1);
				if (score > maxScore)
					maxScore = score;
			}
			return maxScore;
		}
		else
		{
			int minScore = Integer.MAX_VALUE;
			for (State child : addChildren(s))
			{
				int score = minimax(child, d - 1);
				if (score < minScore)
					minScore = score;
			}
			return minScore;
		}

		/*
		 * // retreive highest value element // State largest = s.getChildren()[s.getChildren().length - 1]; // if no children evaluate board // otherwise go through children and recursively call minimax to evaluate each state and assign number to it if (s.getChildren().length == 0) {
		 *//*** EVALUATE BOARD ***/
		/*
		 * evaluateBoard(s); } // sort Arrays.sort(s.getChildren());
		 *//*** GO THROUGH CHILDREN OF S AND RECURSIVELY CALL MINIMAX TO EVAL EACH STATE AND ASSIGN HEURISTIC SCORE ***/
		/*
		 * for (State child : s.getChildren()) { minimax(child); }
		 */

	}

	public State getBestMove(State s, int d)
	{
		int maxScore = Integer.MIN_VALUE;
		State best = null;
		for (State child : addChildren(s))
		{
			int score = minimax(child, d - 1);
			if (score > maxScore)
			{
				maxScore = score;
				best = child;
			}
		}
		return best;
	}

	public int evaluateBoard(State s)
	{
		int score = 0;
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (s.realOriginalBoard[i][j].getColor() == getColor())
				{
					if (s.realOriginalBoard[i][j].isProtected(s.realOriginalBoard))
					{
						score += 10;
					}
					// if can kill, good
					// for each piece close to king, good
					// if can kill better piece very good
				}
				else
				{
					if (s.realOriginalBoard[i][j].isProtected(s.realOriginalBoard))
					{
						score -= 3;
					}
				}

			}
		}
		return score;
	}

	public State[] addChildren(State s)
	{
		// System.gc(); //TODO Do i need this?
		return s.initializeChildren();

	}

	public void movePiece(Piece pieceToMove, Piece[][] bg, int destinationCol, int destinationRow)
	{
		pieceToMove.destroyPiece();
		pieceToMove.setPieceIcon(bg[destinationCol][destinationRow].getPieceIcon());
		pieceToMove.setType(bg[destinationCol][destinationRow].getType());
		pieceToMove.setColor(bg[destinationCol][destinationRow].getColor());

		bg[destinationCol][destinationRow].destroyPiece();
	}

	@Override
	public void runMove(Piece[][] bg)
	{
		System.out.println("Running AI movement for class: " + this);
		updateLocalPieces(bg);
		// runRandomMovement(bg);
		runSmartMovement(bg);
	}

	public void runRandomMovement(Piece[][] bg)
	{
		System.out.println("Running random AI movement");
		boolean hasAtLeastOneMove = false;

		Piece pieceToMove = null;
		boolean[][] moves = new boolean[8][8];
		ArrayList<Point> possibleMoves = null;
		int randCol = -1, randRow = -1;

		while (!hasAtLeastOneMove)
		{
			randCol = rand.nextInt(8);
			randRow = rand.nextInt(8);

			pieceToMove = playersLocalPieces[randCol][randRow];
			moves = pieceToMove.getPossibleMoves(bg);
			possibleMoves = new ArrayList<Point>();

			for (int i = 0; i < 8; i++)
			{
				for (int j = 0; j < 8; j++)
				{
					if (moves[i][j])
					{
						possibleMoves.add(new Point(i, j));
						hasAtLeastOneMove = true;
					}
				}
			}
		}

		Point randomMove = possibleMoves.get(rand.nextInt(possibleMoves.size()));
		System.out.println("Moving to " + randomMove);
		Piece selectedPiece = bg[randomMove.x][randomMove.y];

		movePiece(selectedPiece, bg, randCol, randRow);
	}

	public void updateLocalPieces(Piece[][] bg)
	{
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (bg[i][j].getColor() == getColor())
				{
					playersLocalPieces[i][j] = bg[i][j];
				}
				else
				{
					playersLocalPieces[i][j] = new Piece(new JButton(), Color.white);
				}
			}
		}
	}

}
