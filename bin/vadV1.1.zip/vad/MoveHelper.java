package vad;

import java.util.ArrayList;

public class MoveHelper
{
	public static ArrayList<Position> getReachablePosition(GameBoard board, int col, int row)
	{
		Piece p = board.getPiece(col, row);
		switch (p.getType())
		{
			case Piece.ROOK:
				return getReachableRookPosition(board, p, col, row);
			case Piece.KNIGHT:
				return getReachableKnightPosition(board.board, col, row);
			case Piece.BISHOP:
				return getReachableBishopPosition(board.board, col, row);
			case Piece.KING:
				return getReachableKingPosition(board.board, col, row);
			case Piece.QUEEN:
				return getReachableQueenPosition(board, p, col, row);
			default:
				return getReachablePawnPosition(board.board, col, row);
		}

	}

	public static ArrayList<Move> getAllMoves4PieceWithoutValidation(GameBoard board, Position pos)
	{
		ArrayList<Move> moves = new ArrayList<>();
		for (Position p : getReachablePosition(board, pos.col, pos.row))
		{
			moves.add(new Move(board, pos, p));
		}
		return moves;
	}

	public static ArrayList<Move> getAllMoves4Piece(GameBoard board, Position pos)
	{
		ArrayList<Move> moves = new ArrayList<>();
		Piece piece = board.getPiece(pos);
		for (Position p : getReachablePosition(board, pos.col, pos.row))
		{
			Move m = new Move(board, pos, p);
			board.apply(m);
			if (!board.isCheck(piece.getColor()))
				moves.add(m);
			board.undo(m);
		}
		return moves;
	}

	private static ArrayList<Position> getReachableRookPosition(GameBoard board, Piece piece, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		for (int c = col - 1; c >= 0; c--)
		{
			if (!checkFreeOrEatAndAdd(board.board, position, c, row, piece))
				break;
		}
		for (int c = col + 1; c < 8; c++)
		{
			if (!checkFreeOrEatAndAdd(board.board, position, c, row, piece))
				break;
		}
		for (int r = row - 1; r >= 0; r--)
		{
			if (!checkFreeOrEatAndAdd(board.board, position, col, r, piece))
				break;
		}
		for (int r = row + 1; r < 8; r++)
		{
			if (!checkFreeOrEatAndAdd(board.board, position, col, r, piece))
				break;
		}
		return position;
	}

	private static ArrayList<Position> getReachableKnightPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		Piece p = board[col][row];
		checkFreeOrEatAndAdd(board, position, col - 2, row - 1, p);
		checkFreeOrEatAndAdd(board, position, col - 2, row + 1, p);
		checkFreeOrEatAndAdd(board, position, col + 2, row - 1, p);
		checkFreeOrEatAndAdd(board, position, col + 2, row + 1, p);
		checkFreeOrEatAndAdd(board, position, col - 1, row - 2, p);
		checkFreeOrEatAndAdd(board, position, col - 1, row + 2, p);
		checkFreeOrEatAndAdd(board, position, col + 1, row - 2, p);
		checkFreeOrEatAndAdd(board, position, col + 1, row + 2, p);
		return position;
	}

	private static ArrayList<Position> getReachableBishopPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		Piece p = board[col][row];
		for (int i = 1;; i++)
		{
			if (!checkFreeOrEatAndAdd(board, position, col + i, row + i, p))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeOrEatAndAdd(board, position, col - i, row + i, p))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeOrEatAndAdd(board, position, col - i, row - i, p))
				break;
		}
		for (int i = 1;; i++)
		{
			if (!checkFreeOrEatAndAdd(board, position, col + i, row - i, p))
				break;
		}
		return position;
	}

	private static ArrayList<Position> getReachableKingPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		Piece p = board[col][row];
		checkFreeOrEatAndAdd(board, position, col - 1, row - 1, p);
		checkFreeOrEatAndAdd(board, position, col - 1, row + 1, p);
		checkFreeOrEatAndAdd(board, position, col + 1, row - 1, p);
		checkFreeOrEatAndAdd(board, position, col + 1, row + 1, p);
		checkFreeOrEatAndAdd(board, position, col + 1, row, p);
		checkFreeOrEatAndAdd(board, position, col - 1, row, p);
		checkFreeOrEatAndAdd(board, position, col, row - 1, p);
		checkFreeOrEatAndAdd(board, position, col, row + 1, p);
		return position;
	}

	private static ArrayList<Position> getReachableQueenPosition(GameBoard board, Piece piece, int col, int row)
	{
		ArrayList<Position> position = getReachableRookPosition(board, piece, col, row);
		position.addAll(getReachableBishopPosition(board.board, col, row));
		return position;
	}

	private static ArrayList<Position> getReachablePawnPosition(Piece[][] board, int col, int row)
	{
		ArrayList<Position> position = new ArrayList<>();
		Piece p = board[col][row];
		if (p.getColor() == Piece.BLACK)
		{
			checkEatAndAdd(board, position, col + 1, row + 1, p);
			checkEatAndAdd(board, position, col - 1, row + 1, p);
			if (checkFree(board, col, row + 1))
			{
				position.add(Position.get(col, row + 1));
				if (row == 1)
					checkFreeOrEatAndAdd(board, position, col, row + 2, p);
			}
		}
		else
		{
			checkEatAndAdd(board, position, col + 1, row - 1, p);
			checkEatAndAdd(board, position, col - 1, row - 1, p);
			if (checkFree(board, col, row - 1))
			{
				position.add(Position.get(col, row - 1));
				if (row == 6)
					checkFreeOrEatAndAdd(board, position, col, row - 2, p);
			}
		}
		return position;
	}
	
	

	private static boolean checkFree(Piece[][] board, int col, int row)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		return board[col][row] == null;
	}

/*	private static boolean checkFreeAndAdd(Piece[][] board, ArrayList<Position> arr, int col, int row)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		boolean ret = board[col][row] == null;
		if (ret)
		{
			arr.add(Position.get(col, row));
		}
		return ret;
	}*/

	private static boolean checkFreeOrEatAndAdd(Piece[][] board, ArrayList<Position> arr, int col, int row, Piece c)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		if (board[col][row] == null)
		{
			arr.add(Position.get(col, row));
			return true;
		}
		if (board[col][row].getColor() != c.getColor())
		{
			arr.add(Position.get(col, row));
		}
		return false;
	}

	private static boolean checkEatAndAdd(Piece[][] board, ArrayList<Position> arr, int col, int row, Piece c)
	{
		if (col < 0 || col > 7 || row < 0 || row > 7)
			return false;
		if (board[col][row] == null)
		{
			return true;
		}
		if (board[col][row].getColor() != c.getColor())
		{
			arr.add(Position.get(col, row));
		}
		return false;
	}
}
