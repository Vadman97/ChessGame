package vad;

import java.util.ArrayList;

import vad.NewChessGUI.ClickListener;

public class UserPlayer implements Player, ClickListener
{
	NewChessGUI	gui;
	GameBoard	board;
	Move		move;
	int			playerColor;

	public UserPlayer(int playerColor)
	{
		this.playerColor=playerColor;
		gui = new NewChessGUI(this);
	}

	public void update(GameBoard board)
	{
		gui.updateBoard(board);
	}

	public Move makeMove(GameBoard b)
	{
		board = b;
		synchronized (this)
		{
			try
			{
				wait();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		board = null;
		return move;
	}

	Position		selectedPosition;
	ArrayList<Move>	possibleMoves;

	@Override
	public void onClick(Position position)
	{
		if (board == null)
		{
			return;
		}

		if (!board.isEmpty(position) && board.getPiece(position).getColor() == playerColor)
		{
			if (selectedPosition == position)
			{
				selectedPosition = null;
				gui.clearReachablity();
				return;
			}
			possibleMoves = MoveHelper.getAllMoves4Piece(board, position);
			if (!possibleMoves.isEmpty())
			{
				selectedPosition = position;
				gui.setReachablity(possibleMoves);
			}
		}
		else if (selectedPosition == null)
		{
			return;
		}
		else
		{
			
			for (Move m : possibleMoves)
			{
				if (m.getDestPosition() == position)
				{
					gui.clearReachablity();
					move = m;
					synchronized (this)
					{
						notifyAll();
					}
					return;
				}
			}
			
		}

	}

}
