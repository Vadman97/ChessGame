package vad;

import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class MoveManager
{
	public int			player1Color, player2Color;
	public int			lastMoveBy;
	public int			firstMoveBy;

	public boolean		gameRunning	= false;

	private Image[][]	chessPieceImages;

	public Player[]		players		= new Player[2];

	public MoveManager(int player1Color, int player2Color, int firstMoveBy, Image[][] chessImgs)
	{
		// ///BE CAREFUL WITH COLOR CONSTANTS!!! WHITE IS 1!
		this.player1Color = player1Color;
		this.player2Color = player2Color;
		this.firstMoveBy = firstMoveBy;
		this.gameRunning = true;
		if (this.firstMoveBy == ChessGUI.BLACK) this.lastMoveBy = ChessGUI.WHITE;
		if (this.firstMoveBy == ChessGUI.WHITE) this.lastMoveBy = ChessGUI.BLACK;
		this.chessPieceImages = chessImgs;
		this.players[firstMoveBy] = new Player(player1Color);
		this.players[this.lastMoveBy] = new Player(player2Color);
		if (firstMoveBy == ChessGUI.WHITE)
			ChessGUI.turnIndicator.setText("Turn: " + "White");
		else
			ChessGUI.turnIndicator.setText("Turn: " + "Black");
	}

	public void clearActivePossibleMoves(Piece[][] board)
	{
		for (int ii = 0; ii < 8; ii++)
			for (int jj = 0; jj < 8; jj++)
				if (board[ii][jj].getType() == -1)
					board[ii][jj].destroyPiece();
				else
					board[ii][jj].setPieceIcon(new ImageIcon(this.chessPieceImages[board[ii][jj].getColor()][board[ii][jj].getType()]));
	}

	public void displayPossibleMoves(boolean[][] possibleMoves, Piece[][] board)
	{
		System.out.println("Printing possible moves: ");
		for (int ii = 0; ii < 8; ii++)
			for (int jj = 0; jj < 8; jj++) // row
			{
				if (possibleMoves[ii][jj] == false) continue;
				board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				System.out.println(ii + " " + jj);
			}
	}

	public void displayPossibleMoves(Piece selectedPiece, Piece[][] board)
	{
		if (selectedPiece.isValidPiece())
		{
			boolean[][] possibleMoves = selectedPiece.getPossibleMoves(board);
			for (int ii = 0; ii < 8; ii++)
				for (int jj = 0; jj < 8; jj++) // row
				{
					if (possibleMoves[ii][jj] == false) continue;
					board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				}
		}
	}

	public void displaySquaresUnderEnemyAttack(Piece selectedPiece, Piece[][] board)
	{
		if (selectedPiece.isValidPiece())
		{
			boolean[][] underEAttack = selectedPiece.getAllSquaresUnderEnemyAttack(board, false, false);
			for (int ii = 0; ii < 8; ii++)
				for (int jj = 0; jj < 8; jj++) // row
				{
					if (underEAttack[ii][jj] == false) continue;
					board[ii][jj].setPieceIcon(new ImageIcon(ChessGUI.possibleMoveImg));
				}
		}
	}

	public int getActiveColor()
	{
		if (this.lastMoveBy == ChessGUI.BLACK) return ChessGUI.WHITE;
		if (this.lastMoveBy == ChessGUI.WHITE) return ChessGUI.BLACK;
		return -1;
	}

	public static void printPossibleMoves(boolean[][] possibleMoves)
	{
		System.out.println("Possible moves: ");
		for (int i = 0; i < 8; i++)
			for (int j = 0; j < 8; j++)
				System.out.print(possibleMoves[i][j] ? 1 : 0 + ", ");
		System.out.println();
	}

	public void underCheckPopupMessage(Piece selectedPiece, int currentTurn)
	{
		if (selectedPiece.underCheck(ChessGUI.getBoardGrid(), currentTurn, false)) JOptionPane.showMessageDialog(ChessGUI.gui, "CHECK");
	}

	public boolean isGameOver(Piece selectedPiece)
	{
		if (selectedPiece.checkMate(ChessGUI.getBoardGrid(), ChessGUI.WHITE, false))
		{
			JOptionPane.showMessageDialog(ChessGUI.gui, "CHECKMATE BLACK WINS");
			ChessGUI.turnIndicator.setText("BLACK WINS");
			this.gameRunning = false;
			return true;
		}
		if (selectedPiece.checkMate(ChessGUI.getBoardGrid(), ChessGUI.BLACK, false))
		{
			JOptionPane.showMessageDialog(ChessGUI.gui, "CHECKMATE WHITE WINS");
			ChessGUI.turnIndicator.setText("WHITE WINS");
			this.gameRunning = false;
			return true;
		}
		return false;
	}

	public void processMove(Piece selectedPiece, Piece[][] board) // runs on square clicked
	{
		if (!gameRunning) return;
		int currentTurn;
		if (this.lastMoveBy == ChessGUI.BLACK)
			currentTurn = ChessGUI.WHITE;
		else
			currentTurn = ChessGUI.BLACK;

		if (this.isGameOver(selectedPiece)) return;

		if (ChessGUI.displayAttackSqDEBUG)
		{
			this.clearActivePossibleMoves(board);
			this.displaySquaresUnderEnemyAttack(selectedPiece, board);
			return;
		}

		if (!this.players[currentTurn].hasSelectedPiece()) // if player doesnt have piece selected
		{

			if (!selectedPiece.isValidPiece()) return; // if square clicked is valid

			if (selectedPiece.getColor() != this.players[currentTurn].getColor()) // if piece clicked is of player's color
			{
				this.clearActivePossibleMoves(board);
				System.out.println("ERROR Player pressed on enemy piece");
				return;
			}

			boolean[][] possibleMoves = selectedPiece.getPossibleMoves(board);

			this.players[currentTurn].selectPiece(selectedPiece);
			this.clearActivePossibleMoves(board);
			this.displayPossibleMoves(possibleMoves, board);
		} else
		// else if the players already has a piece selected, need to set new clicked square to piece selected
		{
			this.clearActivePossibleMoves(board);
			boolean[][] possibleMoves = this.players[currentTurn].getSelectedPiece().getPossibleMoves(board);
			if (possibleMoves[selectedPiece.getColumn()][selectedPiece.getRow()]) // valid move location
			{
				System.out.println("Player with selected piece clicked on VALID square, need to MOVE PIECE");

				// this.players[currentTurn].getSelectedPiece() needs to be at selectedPiece
				selectedPiece.destroyPiece();
				selectedPiece.setPieceIcon(this.players[currentTurn].getSelectedPiece().getPieceIcon());
				selectedPiece.setType(this.players[currentTurn].getSelectedPiece().getType());
				selectedPiece.setColor(this.players[currentTurn].getSelectedPiece().getColor());

				this.players[currentTurn].getSelectedPiece().destroyPiece();
				this.players[currentTurn].deselectPiece();

				Piece p = new Piece(new JButton(), Color.white);
				p.setColor(this.lastMoveBy);
				underCheckPopupMessage(p, this.lastMoveBy);

				if (this.lastMoveBy == ChessGUI.BLACK)
					this.lastMoveBy = ChessGUI.WHITE;
				else if (this.lastMoveBy == ChessGUI.WHITE) this.lastMoveBy = ChessGUI.BLACK;
			} else
			// invalid move location, deselect
			{
				System.out.println("Player with selected piece clicked on INVALID square, need to deselect");
				System.out.println(selectedPiece.getColumn() + " " + selectedPiece.getRow());
				// TODO King under check, (? different state or something so that king must go out of check next move)
				// TODO Maybe put underCheck validation into kingMove?
				// TODO Piece cannot move if preventing check
				// TODO King super weird possibleMove patterns
				// this.printPossibleMoves(possibleMoves);

				this.players[currentTurn].deselectPiece();
				return;
			}
		}
		if (this.isGameOver(selectedPiece)) return;

		if (this.lastMoveBy == ChessGUI.WHITE)
			ChessGUI.turnIndicator.setText("Turn: " + "Black");
		else
			ChessGUI.turnIndicator.setText("Turn: " + "White");

		ChessGUI.tools.updateUI();
		ChessGUI.gui.updateUI();
	}
}
