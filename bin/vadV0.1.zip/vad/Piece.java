package vad;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Piece
{
	private JButton		pieceSquareButton;
	private int			row				= -1;
	private int			column			= -1;
	private int			type			= -1;
	private int			teamColor		= -1;
	private final int	BLACK_PAWN_ROW	= 1;
	private final int	WHITE_PAWN_ROW	= 6;
	private Color		blankSquareColor;

	public Piece(JButton b, Color blankSquareColor)
	{
		this.setPieceSquareButton(b);
		this.blankSquareColor = blankSquareColor;
	}

	public void destroyPiece()
	{
		this.pieceSquareButton.setBackground(this.blankSquareColor);
		this.type = -1;
		this.teamColor = -1;
		this.setPieceIcon(new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB)));
	}

	public boolean[][] getAllSquaresUnderEnemyAttack()
	{
		boolean[][] grid = new boolean[8][8];

		Piece[][] enemyPieces = new Piece[8][8];

		for (int i = 0; i < 8; i++)
			for (int j = 0; j < 8; j++)
			{
				Piece p = new Piece(new JButton(), Color.white);
				p.setType(ChessGUI.getBoardGrid()[i][j].getType());
				p.setColor(ChessGUI.getBoardGrid()[i][j].getColor());
				p.setPos(ChessGUI.getBoardGrid()[i][j].getColumn(), ChessGUI.getBoardGrid()[i][j].getRow());
				enemyPieces[i][j] = p;// ChessGUI.getBoardGrid()[i][j];
			}

		for (int i = 0; i < 8; i++)
			for (int j = 0; j < 8; j++)
			{
				if (enemyPieces[i][j].getColor() == this.getColor()) enemyPieces[i][j].destroyPiece();

				if (enemyPieces[i][j].getType() != -1)
				{
					boolean[][] result = enemyPieces[i][j].getAttackLocations(ChessGUI.getBoardGrid());
					for (int ii = 0; ii < 8; ii++)
						for (int jj = 0; jj < 8; jj++)
							if (result[ii][jj]) grid[ii][jj] = true;
				}
			}

		return grid;
	}

	public boolean[][] getAttackLocations(Piece[][] bg)
	{
		boolean[][] grid = new boolean[8][8];

		for (int ii = 0; ii < 8; ii++)
			for (int jj = 0; jj < 8; jj++)
				grid[ii][jj] = false;

		switch (this.type)
		{
			case ChessGUI.BISHOP:
				grid = this.runDiagonalCheck(bg, grid, true);
				break;
			case ChessGUI.KING:
				grid = this.runKingCheck(bg, grid, true);
				break;
			case ChessGUI.KNIGHT:
				grid = this.runKnightCheck(bg, grid);
				break;
			case ChessGUI.PAWN:
				grid = this.runPawnCheck(bg, grid, true);
				break;
			case ChessGUI.QUEEN: // queen and king flipped
				grid = this.runStraightCheck(bg, grid, true);
				grid = this.runDiagonalCheck(bg, grid, true);
				break;
			case ChessGUI.ROOK:
				grid = this.runStraightCheck(bg, grid, true);
				break;
		}

		return grid;
	}

	public Color getBlankSquareColor()
	{
		return this.blankSquareColor;
	}

	public int getColor()
	{
		return this.teamColor;
	}

	public int getColumn()
	{
		return this.column;
	}

	public Icon getPieceIcon()
	{
		return this.pieceSquareButton.getIcon();
	}

	public JButton getPieceSquareButton()
	{
		return this.pieceSquareButton;
	}

	public boolean[][] getPossibleMoves(Piece[][] bg)
	{
		boolean[][] grid = new boolean[8][8];

		for (int ii = 0; ii < 8; ii++)
			for (int jj = 0; jj < 8; jj++)
				grid[ii][jj] = false;

		switch (this.type)
		{
			case ChessGUI.BISHOP:
				grid = this.runDiagonalCheck(bg, grid, false);
				break;
			case ChessGUI.KING:
				grid = this.runKingCheck(bg, grid, false);
				break;
			case ChessGUI.KNIGHT:
				grid = this.runKnightCheck(bg, grid);
				break;
			case ChessGUI.PAWN:
				grid = this.runPawnCheck(bg, grid, false);
				break;
			case ChessGUI.QUEEN:
				grid = this.runStraightCheck(bg, grid, false);
				grid = this.runDiagonalCheck(bg, grid, false);
				break;
			case ChessGUI.ROOK:
				grid = this.runStraightCheck(bg, grid, false);
				break;
		}

		return grid;
	}

	public int getRow()
	{
		return this.row;
	}

	public int getType()
	{
		return this.type;
	}

	public boolean isValidPiece()
	{
		if ((this.getType() == -1) || (this.getRow() == -1) || (this.getColumn() == -1) || (this.getColor() == -1)) return false;
		return true;
	}

	public boolean[][] runDiagonalCheck(Piece[][] bg, boolean[][] grid, boolean noBreaks)
	{
		boolean ran = false;
		boolean ran2 = false;
		boolean ran3 = false;
		while (true)
		{
			int col = this.getColumn();
			int row = this.getRow();
			System.out.println("StartDiagonalCheck: " + col + " " + row);
			while (((col < 8) && (row >= 0)) && (col >= 0) && (row < 8))
			{
				System.out.println("DEBUG_DiagonalCheck: " + col + " " + row);

				if (bg[col][row].getType() == -1)
					grid[col][row] = true;

				else if (bg[col][row].getColor() != this.getColor())
				{
					grid[col][row] = true;
					if (!noBreaks) break;
				} else if ((this.getColumn() != bg[col][row].getColumn()) || (this.getRow() != bg[col][row].getRow())) if (bg[col][row].getColor() == this.getColor()) break;

				if (ran2)
				{
					if (ran)
						col--;
					else
						col++;
					row--;
				} else
				{
					if (ran)
						col--;
					else
						col++;
					row++;
				}
			}
			if (ran3) break;

			if (ran && ran2)
			{
				ran3 = true;
				ran2 = true;
				ran = false;
				continue;
			}

			if (ran)
			{
				ran2 = true;
				ran = false;
			}

			ran = true;
		}
		return grid;
	}

	public boolean[][] runKingCheck(Piece[][] bg, boolean[][] grid, boolean recursiveAvoid)
	{
		int col = this.getColumn();
		int row = this.getRow();
		System.out.println("StartKingCheck: " + col + " " + row + " " + recursiveAvoid);
		for (int i = -1; i < 2; i++)
		{
			row = this.getRow();
			row += i;
			for (int j = -1; j < 2; j++)
			{
				col = this.getColumn();
				col += j;

				if (((col >= 8) || (row < 0)) || (col < 0) || (row >= 8)) continue;

				if (!recursiveAvoid && this.getAllSquaresUnderEnemyAttack()[col][row])
				{
					System.out.println("KING DETECTED ATTACK: " + recursiveAvoid + " " + this.getAllSquaresUnderEnemyAttack()[col][row]);
					continue;
				}

				if (bg[col][row].getType() == -1)
					grid[col][row] = true;
				else if (bg[col][row].getColor() != this.getColor())
				{
					grid[col][row] = true;
					break;
				}
			}
		}

		return grid;
	}

	public boolean[][] runKnightCheck(Piece[][] bg, boolean[][] grid)
	{
		for (int i = 0; i < 4; i++)
		{
			int col = this.getColumn();
			int row = this.getRow();
			System.out.println("StartKnightCheck: " + col + " " + row);

			if (i == 0)
				row -= 2;
			else if (i == 1)
				col += 2;
			else if (i == 2)
				row += 2;
			else if (i == 3) col -= 2;

			for (int j = 0; j < 2; j++)
			{
				if ((i % 2) == 0)
					col = this.getColumn();
				else
					row = this.getRow();

				System.out.println("DEBUG_KnightCheck: " + col + " " + row);

				if ((i % 2) == 0)
				{
					if (j == 0)
						col--;
					else
						col++;
				} else if (j == 0)
					row--;
				else
					row++;

				if (((col >= 8) || (row < 0)) || (col < 0) || (row >= 8)) continue;

				if (bg[col][row].getType() == -1)
					grid[col][row] = true;
				else if (bg[col][row].getColor() != this.getColor()) grid[col][row] = true;
			}
		}
		return grid;
	}

	public boolean[][] runPawnCheck(Piece[][] bg, boolean[][] grid, boolean attack)
	{
		if (this.teamColor == ChessGUI.WHITE)
		{
			// check for edge of board
			if ((this.getRow() - 1) < 0) return grid;
			// check if space straight ahead is blank
			if (bg[this.getColumn()][this.getRow() - 1].getType() == -1) grid[this.getColumn()][this.getRow() - 1] = true;
			// check if on starting row, can jump 2 spaces
			if ((this.getRow() == this.WHITE_PAWN_ROW) && !attack)
				if (bg[this.getColumn()][this.getRow() - 1].getType() == -1) if (bg[this.getColumn()][this.getRow() - 2].getType() == -1) grid[this.getColumn()][this.getRow() - 2] = true;

			// check for edge of board, then see if can attack right
			// ahead
			if (!((this.getColumn() + 1) > 7))
				if (bg[this.getColumn() + 1][this.getRow() - 1].getColor() != this.getColor())
					if (bg[this.getColumn() + 1][this.getRow() - 1].getType() != -1) grid[this.getColumn() + 1][this.getRow() - 1] = true;
			// check for edge of board, then see if can attack left
			// ahead
			if (!((this.getColumn() - 1) < 0))
				if (bg[this.getColumn() - 1][this.getRow() - 1].getColor() != this.getColor())
					if (bg[this.getColumn() - 1][this.getRow() - 1].getType() != -1) grid[this.getColumn() - 1][this.getRow() - 1] = true;

		} else
		{
			// check for edge of board
			if ((this.getRow() + 1) > 7) return grid;
			// check if space straight ahead is blank
			if (bg[this.getColumn()][this.getRow() + 1].getType() == -1) grid[this.getColumn()][this.getRow() + 1] = true;
			// check if on starting row, can jump 2 spaces
			if ((this.getRow() == this.BLACK_PAWN_ROW) && !attack)
				if (bg[this.getColumn()][this.getRow() + 1].getType() == -1) if (bg[this.getColumn()][this.getRow() + 2].getType() == -1) grid[this.getColumn()][this.getRow() + 2] = true;

			// check for edge of board, then see if can attack right
			// ahead
			if (!((this.getColumn() - 1) < 0))
				if (bg[this.getColumn() - 1][this.getRow() + 1].getColor() != this.getColor())
					if (bg[this.getColumn() - 1][this.getRow() + 1].getType() != -1) grid[this.getColumn() - 1][this.getRow() + 1] = true;
			// check for edge of board, then see if can attack left
			// ahead
			if (!((this.getColumn() + 1) > 7))
				if (bg[this.getColumn() + 1][this.getRow() + 1].getColor() != this.getColor())
					if (bg[this.getColumn() + 1][this.getRow() + 1].getType() != -1) grid[this.getColumn() + 1][this.getRow() + 1] = true;
		}
		return grid;
	}

	public boolean[][] runStraightCheck(Piece[][] bg, boolean[][] grid, boolean noBreaks)
	{
		for (int i = 0; i < 4; i++)
		{
			int col = this.getColumn();
			int row = this.getRow();
			System.out.println("StartStraightCheck: " + col + " " + row);
			while (((col < 8) & (row >= 0)) && (col >= 0) && (row < 8))
			{
				System.out.println("DEBUG_StraightCheck: " + col + " " + row);

				if (bg[col][row].getType() == -1)
					grid[col][row] = true;
				else if (bg[col][row].getColor() != this.getColor())
				{
					grid[col][row] = true;
					if (!noBreaks) break;
				} else if ((this.getColumn() != bg[col][row].getColumn()) || (this.getRow() != bg[col][row].getRow())) if (bg[col][row].getColor() == this.getColor()) break;

				if (i == 0)
					col++;
				else if (i == 1)
					row++;
				else if (i == 2)
					col--;
				else if (i == 3) row--;
			}
		}
		return grid;
	}

	public void setActionListener(ActionListener al)
	{
		this.pieceSquareButton.addActionListener(al);
	}

	public void setColor(int color)
	{
		this.teamColor = color;
	}

	public void setPieceIcon(ImageIcon imageIcon)
	{
		this.pieceSquareButton.setIcon(imageIcon);
	}

	public void setPieceSquareButton(JButton pieceSquareButton)
	{
		this.pieceSquareButton = pieceSquareButton;
	}

	public void setPos(int col, int row)
	{
		this.row = row;
		this.column = col;
	}

	public void setType(int type)
	{
		this.type = type;
	}
}
