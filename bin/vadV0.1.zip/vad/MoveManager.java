package vad;

public class MoveManager
{
	  
}
